@javax.xml.bind.annotation.XmlSchema(namespace = "http://services.company.tqi.com.br/")
package br.com.tqi.company.ws.client;
